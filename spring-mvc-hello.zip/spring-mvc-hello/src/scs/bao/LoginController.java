package scs.bao;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Query;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import helper.HiberTemplate;
import scs.dao.*;

@Controller
public class LoginController {
	@RequestMapping("login")
	public ModelAndView loginFunction()
	{  
		return new ModelAndView("adminlogin","command",new Admin());
	}
	@RequestMapping("logincode")
	public ModelAndView loginCodeFunction(@ModelAttribute("spring-mvc-hello")Admin s,ModelMap model,HttpServletRequest request)
	{  
HiberTemplate.scsConfigure();
String query = "from Admin a where a.username=:a and a.password=:b";
		Query q = HiberTemplate.loginData(query,s.getUsername(),s.getPassword());
		List lst = q.list();
		String data = "";
		if(lst.size()>0)
		{
			HttpSession session = request.getSession();
			session.setAttribute("suid",s.getUsername());
			return new ModelAndView("redirect:siload.do");
			//data = "login sucess";
		}
		else
		{
			data = "login fail";
			
		}
		model.put("res",data);
		return new ModelAndView("adminlogin","command",new Admin());
	}
}
