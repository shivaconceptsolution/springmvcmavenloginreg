package scs.bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
	@RequestMapping("ram")
	public String displayHello()
	{
		return "welcome";
	}
	@RequestMapping("shyam")
	public String displayshyam()
	{
		return "shyam";
	}

}
