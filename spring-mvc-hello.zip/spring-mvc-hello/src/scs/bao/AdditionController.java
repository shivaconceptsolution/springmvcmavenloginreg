package scs.bao;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
@Controller
public class AdditionController {
@RequestMapping("add")
public ModelAndView addition(HttpServletRequest request, HttpServletResponse response)
{
	if(request.getParameter("btnsubmit")!=null)
	{
		int a,b,c;
		a = Integer.parseInt(request.getParameter("txtnum1"));
		b = Integer.parseInt(request.getParameter("txtnum2"));
		c=a+b;
		return new ModelAndView("add","res","Result is "+c);
		
	}
	
	return new ModelAndView("add");
}

@RequestMapping("sub")
public ModelAndView substraction()
{
	int a=100,b=200,c;
	c=a-b;
	return new ModelAndView("sub","res","Result is "+c);
}
}
