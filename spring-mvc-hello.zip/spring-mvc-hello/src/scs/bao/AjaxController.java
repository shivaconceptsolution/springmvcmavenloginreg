package scs.bao;

import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import helper.HiberTemplate;
import scs.dao.Admin;
import scs.dao.Reg;

@Controller
public class AjaxController {
	@RequestMapping("reg")
	public ModelAndView regFunction()
	{  
		return new ModelAndView("reg");
	}
	@RequestMapping("regcode")
	public ModelAndView regCodeFunction(HttpServletRequest request)
	{  
		String uid = request.getParameter("uname");
		String pwd = request.getParameter("pwd");
		String mobile = request.getParameter("mobile");
		HiberTemplate.scsConfigure();
		Reg r = new Reg();
		r.setUid(uid);
		r.setPwd(pwd);
		r.setMobile(mobile);
		HiberTemplate.scsInsertData(r);
		HiberTemplate.closeConn();
		return new ModelAndView("success");
	}
}
